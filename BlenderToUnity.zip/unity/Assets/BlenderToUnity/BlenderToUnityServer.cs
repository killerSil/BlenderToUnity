// BlenderToUnity — servidor Unity
// Recebe malhas/transforms/hierarquia/materiais/animação do Blender via TCP
// e reconstrói tudo na cena, em Edit Mode e em Play Mode.
//
// Uso: GameObject > BlenderToUnity > Criar Servidor  (ou adiciona o componente
// BlenderToUnityServer a um GameObject). Depois liga a partir do Blender.
//
// Sem DLLs nativas, sem dependências — só este ficheiro.

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using UnityEngine;
using UnityEngine.Rendering;
#if UNITY_EDITOR
using UnityEditor;
#endif

[ExecuteAlways]
[AddComponentMenu("BlenderToUnity/BlenderToUnity Server")]
public class BlenderToUnityServer : MonoBehaviour
{
    [Header("Rede")]
    public int port = 9931;
    public bool autoStart = true;

    [Header("Conversão")]
    [Tooltip("Inverte a ordem dos triângulos (necessário na conversão Blender→Unity).")]
    public bool flipFaces = true;
    [Tooltip("Escala global aplicada às posições e malhas.")]
    public float scaleFactor = 1f;

    [Header("Limites")]
    [Tooltip("Mensagens aplicadas por frame (evita travar com cenas grandes).")]
    public int maxMessagesPerUpdate = 8;

    [Header("Assets (só no Editor)")]
    [Tooltip("Grava as texturas recebidas como ficheiros em Assets/ (persistem no projeto).")]
    public bool saveTexturesAsAssets = true;
    [Tooltip("Pasta dentro do projeto onde as texturas são gravadas.")]
    public string textureFolder = "Assets/BlenderToUnity/Textures";

    [Header("Estado (leitura)")]
    [SerializeField] string status = "Parado";
    [SerializeField] int objectCount;

    // ------------------------------------------------------------------
    // Protocolo (tem de bater certo com blender_to_unity.py)
    // ------------------------------------------------------------------
    const uint MAGIC = 0x42545531; // "BTU1"
    const uint MSG_HELLO = 1, MSG_OBJECT = 2, MSG_DELETE = 3, MSG_CLEAR = 4, MSG_TEXTURE = 5;

    [Serializable]
    class SubMeshInfo
    {
        public string material;
        public float[] color;
        public float metallic;
        public float roughness;
        public float[] emission;
        public string texture;       // base color
        public string normalTex;
        public string roughnessTex;
        public string metallicTex;
        public string emissionTex;
        public int indexCount;
    }
    [Serializable] class ObjectMsg
    {
        public string path; public string parent;
        public float[] t; public float[] r; public float[] s;
        public bool visible; public bool hasMesh;
        public int vertexCount; public bool hasUV;
        public SubMeshInfo[] submeshes;
    }
    [Serializable] class DeleteMsg { public string path; }
    [Serializable] class TextureMsg { public string name; public string format; public string usage; }

    struct Frame { public uint type; public string json; public byte[] bin; }

    TcpListener listener;
    Thread netThread;
    volatile bool running;
    readonly ConcurrentQueue<Frame> queue = new ConcurrentQueue<Frame>();
    readonly Dictionary<string, Material> materialCache = new Dictionary<string, Material>();
    readonly Dictionary<string, Texture2D> textureCache = new Dictionary<string, Texture2D>();
    readonly Dictionary<string, string> textureUsage = new Dictionary<string, string>();     // textura -> color|normal|data
    readonly Dictionary<string, SubMeshInfo> materialInfo = new Dictionary<string, SubMeshInfo>(); // material -> último PBR recebido

    public volatile bool clientConnected; // true enquanto o Blender está ligado
    public string Status => status;
    public int ObjectCount => objectCount;
    Transform syncRoot;

    // ------------------------------------------------------------------
    // Ciclo de vida
    // ------------------------------------------------------------------
    void OnEnable()
    {
        if (autoStart) StartServer();
#if UNITY_EDITOR
        EditorApplication.update -= EditorTick;
        EditorApplication.update += EditorTick;
#endif
    }

    void OnDisable()
    {
#if UNITY_EDITOR
        EditorApplication.update -= EditorTick;
#endif
        StopServer();
    }

    void Update()
    {
        if (Application.isPlaying) Pump();
    }

#if UNITY_EDITOR
    void EditorTick()
    {
        if (!Application.isPlaying && this != null) Pump();
    }
#endif

    // ------------------------------------------------------------------
    // Servidor TCP (thread de fundo)
    // ------------------------------------------------------------------
    public void StartServer()
    {
        if (running) return;
        try
        {
            listener = new TcpListener(IPAddress.Any, port);
            listener.Start();
            running = true;
            netThread = new Thread(NetLoop) { IsBackground = true, Name = "BlenderToUnity" };
            netThread.Start();
            status = $"À escuta na porta {port}";
            Debug.Log($"[BlenderToUnity] {status}");
        }
        catch (Exception e)
        {
            status = "Erro: " + e.Message;
            Debug.LogError("[BlenderToUnity] " + e.Message);
        }
    }

    public void StopServer()
    {
        running = false;
        clientConnected = false;
        try { listener?.Stop(); } catch { }
        listener = null;
        netThread = null;
        status = "Parado";
    }

    void NetLoop()
    {
        while (running)
        {
            TcpClient client = null;
            try
            {
                client = listener.AcceptTcpClient();
                client.NoDelay = true;
                clientConnected = true;
                status = "Blender ligado: " + client.Client.RemoteEndPoint;
                using (var stream = client.GetStream())
                {
                    var header = new byte[16];
                    while (running)
                    {
                        ReadExact(stream, header, 16);
                        uint magic = BitConverter.ToUInt32(header, 0);
                        if (magic != MAGIC) throw new IOException("Magic inválido — protocolo dessincronizado.");
                        uint type = BitConverter.ToUInt32(header, 4);
                        int lenJson = BitConverter.ToInt32(header, 8);
                        int lenBin = BitConverter.ToInt32(header, 12);
                        if (lenJson < 0 || lenBin < 0 || lenJson > 64 << 20 || lenBin > 512 << 20)
                            throw new IOException("Frame demasiado grande.");

                        var jsonBytes = new byte[lenJson];
                        if (lenJson > 0) ReadExact(stream, jsonBytes, lenJson);
                        var bin = new byte[lenBin];
                        if (lenBin > 0) ReadExact(stream, bin, lenBin);

                        queue.Enqueue(new Frame
                        {
                            type = type,
                            json = lenJson > 0 ? Encoding.UTF8.GetString(jsonBytes) : "",
                            bin = bin
                        });
                    }
                }
            }
            catch (Exception)
            {
                if (running) status = $"À escuta na porta {port}";
            }
            finally
            {
                clientConnected = false;
                try { client?.Close(); } catch { }
            }
        }
    }

    static void ReadExact(NetworkStream s, byte[] buf, int count)
    {
        int off = 0;
        while (off < count)
        {
            int n = s.Read(buf, off, count - off);
            if (n <= 0) throw new IOException("Ligação fechada.");
            off += n;
        }
    }

    // ------------------------------------------------------------------
    // Aplicar mensagens (thread principal)
    // ------------------------------------------------------------------
    void Pump()
    {
        int n = 0;
        bool changed = false;
        while (n < maxMessagesPerUpdate && queue.TryDequeue(out var f))
        {
            n++;
            try
            {
                switch (f.type)
                {
                    case MSG_HELLO:
                        Debug.Log("[BlenderToUnity] Blender ligado: " + f.json);
                        break;
                    case MSG_OBJECT:
                        ApplyObject(JsonUtility.FromJson<ObjectMsg>(f.json), f.bin);
                        changed = true;
                        break;
                    case MSG_DELETE:
                        var d = JsonUtility.FromJson<DeleteMsg>(f.json);
                        var t = GetRoot().Find(d.path);
                        if (t != null) SafeDestroy(t.gameObject);
                        changed = true;
                        break;
                    case MSG_CLEAR:
                        var root = GetRoot();
                        for (int i = root.childCount - 1; i >= 0; i--)
                            SafeDestroy(root.GetChild(i).gameObject);
                        changed = true;
                        break;
                    case MSG_TEXTURE:
                        ApplyTexture(JsonUtility.FromJson<TextureMsg>(f.json), f.bin);
                        changed = true;
                        break;
                }
            }
            catch (Exception e) { Debug.LogException(e); }
        }

        if (changed)
        {
            objectCount = GetRoot().childCount;
#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                SceneView.RepaintAll();
                EditorApplication.QueuePlayerLoopUpdate();
            }
#endif
        }
    }

    Transform GetRoot()
    {
        if (syncRoot == null)
        {
            var existing = transform.Find("BlenderSync");
            if (existing != null) syncRoot = existing;
            else
            {
                var go = new GameObject("BlenderSync");
                go.transform.SetParent(transform, false);
                syncRoot = go.transform;
            }
        }
        return syncRoot;
    }

    void ApplyObject(ObjectMsg m, byte[] bin)
    {
        var root = GetRoot();

        // hierarquia: pai primeiro (placeholder se ainda não chegou)
        Transform parent = root;
        if (!string.IsNullOrEmpty(m.parent))
        {
            var p = FindDeep(root, m.parent);
            if (p == null)
            {
                var pgo = new GameObject(m.parent);
                pgo.transform.SetParent(root, false);
                p = pgo.transform;
            }
            parent = p;
        }

        var tr = FindDeep(root, m.path);
        if (tr == null)
        {
            var go = new GameObject(m.path);
            tr = go.transform;
        }
        if (tr.parent != parent) tr.SetParent(parent, false);

        // Blender (Z-up, RH) → Unity (Y-up, LH): (x,y,z) → (x,z,y)
        tr.localPosition = new Vector3(m.t[0], m.t[2], m.t[1]) * scaleFactor;
        tr.localRotation = new Quaternion(m.r[0], m.r[2], m.r[1], -m.r[3]);
        tr.localScale = new Vector3(m.s[0], m.s[2], m.s[1]);
        tr.gameObject.SetActive(m.visible);

        if (m.hasMesh) ApplyMesh(tr.gameObject, m, bin);
    }

    static Transform FindDeep(Transform root, string name)
    {
        for (int i = 0; i < root.childCount; i++)
        {
            var c = root.GetChild(i);
            if (c.name == name) return c;
            var r = FindDeep(c, name);
            if (r != null) return r;
        }
        return null;
    }

    void ApplyMesh(GameObject go, ObjectMsg m, byte[] bin)
    {
        var mf = go.GetComponent<MeshFilter>();
        if (mf == null) mf = go.AddComponent<MeshFilter>();
        var mr = go.GetComponent<MeshRenderer>();
        if (mr == null) mr = go.AddComponent<MeshRenderer>();

        var mesh = mf.sharedMesh;
        if (mesh == null || !mesh.name.StartsWith("BTU_"))
        {
            mesh = new Mesh { name = "BTU_" + m.path };
            mesh.MarkDynamic();
            mf.sharedMesh = mesh;
        }

        int L = m.vertexCount;
        if (L == 0) { mesh.Clear(); return; }

        int totalIdx = 0;
        foreach (var sm in m.submeshes) totalIdx += sm.indexCount;

        // layout binário: pos(3f*L) | normais(3f*L) | uv(2f*L se hasUV) | índices(int*total)
        int o = 0;
        var verts = new Vector3[L];
        var norms = new Vector3[L];
        float sf = scaleFactor;
        for (int i = 0; i < L; i++, o += 12)
        {
            float x = BitConverter.ToSingle(bin, o);
            float y = BitConverter.ToSingle(bin, o + 4);
            float z = BitConverter.ToSingle(bin, o + 8);
            verts[i] = new Vector3(x, z, y) * sf;
        }
        for (int i = 0; i < L; i++, o += 12)
        {
            float x = BitConverter.ToSingle(bin, o);
            float y = BitConverter.ToSingle(bin, o + 4);
            float z = BitConverter.ToSingle(bin, o + 8);
            norms[i] = new Vector3(x, z, y);
        }
        Vector2[] uvs = null;
        if (m.hasUV)
        {
            uvs = new Vector2[L];
            for (int i = 0; i < L; i++, o += 8)
                uvs[i] = new Vector2(BitConverter.ToSingle(bin, o), BitConverter.ToSingle(bin, o + 4));
        }

        mesh.Clear();
        mesh.indexFormat = L > 65000 ? IndexFormat.UInt32 : IndexFormat.UInt16;
        mesh.vertices = verts;
        mesh.normals = norms;
        if (uvs != null) mesh.uv = uvs;

        int nSub = Mathf.Max(1, m.submeshes.Length);
        mesh.subMeshCount = nSub;
        var mats = new Material[nSub];
        int idxOff = o;
        for (int s = 0; s < m.submeshes.Length; s++)
        {
            var sm = m.submeshes[s];
            var tris = new int[sm.indexCount];
            if (flipFaces)
            {
                for (int i = 0; i < sm.indexCount; i += 3)
                {
                    tris[i]     = BitConverter.ToInt32(bin, idxOff + i * 4);
                    tris[i + 1] = BitConverter.ToInt32(bin, idxOff + (i + 2) * 4);
                    tris[i + 2] = BitConverter.ToInt32(bin, idxOff + (i + 1) * 4);
                }
            }
            else
            {
                for (int i = 0; i < sm.indexCount; i++)
                    tris[i] = BitConverter.ToInt32(bin, idxOff + i * 4);
            }
            idxOff += sm.indexCount * 4;
            mesh.SetTriangles(tris, s, false);
            mats[s] = GetMaterial(sm);
        }
        mesh.RecalculateBounds();
        mr.sharedMaterials = mats;
    }

    void ApplyTexture(TextureMsg tm, byte[] bin)
    {
        if (string.IsNullOrEmpty(tm.name) || bin == null || bin.Length == 0) return;

        string usage = string.IsNullOrEmpty(tm.usage) ? "color" : tm.usage;
        textureUsage[tm.name] = usage;
        Texture2D tex = null;

#if UNITY_EDITOR
        // Gravar como asset real no projeto (persiste entre sessões)
        if (saveTexturesAsAssets)
        {
            try
            {
                string folder = string.IsNullOrEmpty(textureFolder)
                    ? "Assets/BlenderToUnity/Textures" : textureFolder.TrimEnd('/');
                Directory.CreateDirectory(folder);

                string ext = tm.format == "jpg" ? ".jpg" : ".png";
                string assetPath = folder + "/" + SanitizeFileName(tm.name, ext) + ext;

                File.WriteAllBytes(assetPath, bin);
                AssetDatabase.ImportAsset(assetPath, ImportAssetOptions.ForceUpdate);

                // definições de importação conforme o tipo de mapa
                var imp = AssetImporter.GetAtPath(assetPath) as TextureImporter;
                if (imp != null)
                {
                    bool reimport = false;
                    if (usage == "normal" && imp.textureType != TextureImporterType.NormalMap)
                    { imp.textureType = TextureImporterType.NormalMap; reimport = true; }
                    if (usage == "data" && imp.sRGBTexture)
                    { imp.sRGBTexture = false; reimport = true; } // roughness/metallic em linear
                    if (reimport) imp.SaveAndReimport();
                }
                tex = AssetDatabase.LoadAssetAtPath<Texture2D>(assetPath);
            }
            catch (Exception e)
            {
                Debug.LogWarning("[BlenderToUnity] Falha a gravar textura como asset: " + e.Message);
            }
        }
#endif

        // Fallback / runtime: textura em memória
        if (tex == null)
        {
            if (!textureCache.TryGetValue(tm.name, out tex) || tex == null
#if UNITY_EDITOR
                || AssetDatabase.Contains(tex) // antes era asset, agora desligaram a opção
#endif
                )
                tex = new Texture2D(2, 2, TextureFormat.RGBA32, true) { name = "BTU_" + tm.name };

            if (!tex.LoadImage(bin)) // descodifica PNG/JPG e redimensiona sozinho
            {
                Debug.LogWarning("[BlenderToUnity] Falha a descodificar textura: " + tm.name);
                return;
            }
            tex.wrapMode = TextureWrapMode.Repeat;
        }

        textureCache[tm.name] = tex;

        // atualizar materiais que usam esta textura em qualquer canal
        foreach (var kv in materialInfo)
        {
            var i = kv.Value;
            if (i == null) continue;
            if (i.texture == tm.name || i.normalTex == tm.name || i.roughnessTex == tm.name ||
                i.metallicTex == tm.name || i.emissionTex == tm.name)
                if (materialCache.TryGetValue(kv.Key, out var m) && m != null)
                    ApplyPbrToMaterial(m, i);
        }
    }

    static string SanitizeFileName(string name, string ext)
    {
        // remove extensão duplicada ("madeira.png" -> "madeira") e caracteres inválidos
        if (name.EndsWith(ext, StringComparison.OrdinalIgnoreCase))
            name = name.Substring(0, name.Length - ext.Length);
        foreach (char c in Path.GetInvalidFileNameChars())
            name = name.Replace(c, '_');
        return string.IsNullOrEmpty(name) ? "textura" : name;
    }

    Texture2D ResolveTexture(string name)
    {
        if (string.IsNullOrEmpty(name)) return null;
        if (textureCache.TryGetValue(name, out var t) && t != null) return t;
#if UNITY_EDITOR
        // tenta carregar o asset gravado numa sessão anterior
        if (saveTexturesAsAssets)
        {
            string folder = string.IsNullOrEmpty(textureFolder)
                ? "Assets/BlenderToUnity/Textures" : textureFolder.TrimEnd('/');
            foreach (string ext in new[] { ".png", ".jpg" })
            {
                var saved = AssetDatabase.LoadAssetAtPath<Texture2D>(
                    folder + "/" + SanitizeFileName(name, ext) + ext);
                if (saved != null) { textureCache[name] = saved; return saved; }
            }
        }
#endif
        return null;
    }

    static void SetTex(Material m, Texture2D tex, params string[] props)
    {
        foreach (var p in props)
            if (m.HasProperty(p)) m.SetTexture(p, tex);
    }

    void ApplyPbrToMaterial(Material mat, SubMeshInfo sm)
    {
        // ---- Base Color ----
        var baseTex = ResolveTexture(sm.texture);
        SetTex(mat, baseTex, "_BaseMap", "_BaseColorMap", "_MainTex"); // URP, HDRP, Built-in
        Color baseCol = Color.white;
        if (baseTex == null && sm.color != null && sm.color.Length >= 4)
            baseCol = new Color(sm.color[0], sm.color[1], sm.color[2], sm.color[3]);
        if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", baseCol);
        if (mat.HasProperty("_Color")) mat.SetColor("_Color", baseCol);

        // ---- Normal ----
        var nTex = ResolveTexture(sm.normalTex);
        SetTex(mat, nTex, "_BumpMap", "_NormalMap");
        if (nTex != null) { mat.EnableKeyword("_NORMALMAP"); }
        else mat.DisableKeyword("_NORMALMAP");

        // ---- Roughness → Smoothness (Unity usa o inverso) ----
        var rTex = ResolveTexture(sm.roughnessTex);
        float smooth = Mathf.Clamp01(1f - sm.roughness);
        if (mat.HasProperty("_Smoothness")) mat.SetFloat("_Smoothness", rTex != null ? 0.5f : smooth);
        if (mat.HasProperty("_Glossiness")) mat.SetFloat("_Glossiness", rTex != null ? 0.5f : smooth);

        // ---- Metallic ----
        var mTex = ResolveTexture(sm.metallicTex);
        SetTex(mat, mTex, "_MetallicGlossMap", "_MaskMap");
        if (mTex != null) mat.EnableKeyword("_METALLICGLOSSMAP");
        else
        {
            mat.DisableKeyword("_METALLICGLOSSMAP");
            if (mat.HasProperty("_Metallic")) mat.SetFloat("_Metallic", sm.metallic);
        }

        // ---- Emission ----
        var eTex = ResolveTexture(sm.emissionTex);
        Color eCol = (sm.emission != null && sm.emission.Length >= 3)
            ? new Color(sm.emission[0], sm.emission[1], sm.emission[2]) : Color.black;
        bool emissive = eTex != null || eCol.maxColorComponent > 0.001f;
        SetTex(mat, eTex, "_EmissionMap", "_EmissiveColorMap");
        if (emissive)
        {
            mat.EnableKeyword("_EMISSION");
            mat.globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive;
            var c = eTex != null && eCol.maxColorComponent < 0.001f ? Color.white : eCol;
            if (mat.HasProperty("_EmissionColor")) mat.SetColor("_EmissionColor", c);
            if (mat.HasProperty("_EmissiveColor")) mat.SetColor("_EmissiveColor", c);
        }
        else
        {
            mat.DisableKeyword("_EMISSION");
            if (mat.HasProperty("_EmissionColor")) mat.SetColor("_EmissionColor", Color.black);
        }
    }

    Material GetMaterial(SubMeshInfo sm)
    {
        string key = sm.material ?? "Default";
        if (!materialCache.TryGetValue(key, out var mat) || mat == null)
        {
            var shader = Shader.Find("Universal Render Pipeline/Lit")
                      ?? Shader.Find("HDRP/Lit")
                      ?? Shader.Find("Standard");
            mat = new Material(shader) { name = "BTU_" + key };
            materialCache[key] = mat;
        }
        materialInfo[key] = sm;
        ApplyPbrToMaterial(mat, sm);
        return mat;
    }

    static void SafeDestroy(UnityEngine.Object obj)
    {
        if (Application.isPlaying) Destroy(obj);
        else DestroyImmediate(obj);
    }

#if UNITY_EDITOR
    [MenuItem("GameObject/BlenderToUnity/Criar Servidor", false, 10)]
    static void CreateServer()
    {
        if (FindObjectOfType<BlenderToUnityServer>() != null)
        {
            Debug.LogWarning("[BlenderToUnity] Já existe um servidor na cena.");
            return;
        }
        var go = new GameObject("BlenderToUnityServer");
        go.AddComponent<BlenderToUnityServer>();
        Undo.RegisterCreatedObjectUndo(go, "Criar BlenderToUnity Server");
        Selection.activeGameObject = go;
    }
#endif
}

#if UNITY_EDITOR
[CustomEditor(typeof(BlenderToUnityServer))]
class BlenderToUnityServerEditor : Editor
{
    // paleta "sci-fi"
    static readonly Color BgDark   = new Color(0.07f, 0.09f, 0.13f);
    static readonly Color Cyan     = new Color(0.20f, 0.90f, 1.00f);
    static readonly Color Green    = new Color(0.25f, 1.00f, 0.55f);
    static readonly Color Amber    = new Color(1.00f, 0.75f, 0.25f);
    static readonly Color Red      = new Color(1.00f, 0.30f, 0.35f);
    static readonly Color LineDim  = new Color(0.25f, 0.55f, 0.65f, 0.6f);

    static GUIStyle _title, _label, _value, _btn;
    double lastRepaint;

    void Ensure()
    {
        if (_title != null) return;
        _title = new GUIStyle(EditorStyles.boldLabel)
        { fontSize = 14, alignment = TextAnchor.MiddleCenter, normal = { textColor = Cyan } };
        _label = new GUIStyle(EditorStyles.label)
        { fontSize = 10, normal = { textColor = new Color(0.55f, 0.75f, 0.85f) } };
        _value = new GUIStyle(EditorStyles.boldLabel)
        { fontSize = 11, normal = { textColor = Color.white } };
        _btn = new GUIStyle(GUI.skin.button) { fontSize = 11, fontStyle = FontStyle.Bold };
    }

    public override bool RequiresConstantRepaint() => true;

    public override void OnInspectorGUI()
    {
        Ensure();
        var srv = (BlenderToUnityServer)target;

        bool serverOn = srv.Status != "Parado" && !srv.Status.StartsWith("Erro");
        bool blenderOn = srv.clientConnected;
        Color stateColor = blenderOn ? Green : (serverOn ? Amber : Red);
        string stateText = blenderOn ? "● BLENDER LIGADO"
                          : serverOn ? "◌ À ESPERA DO BLENDER"
                                     : "○ OFFLINE";

        // ───────── painel principal ─────────
        var panel = EditorGUILayout.BeginVertical();
        GUILayout.Space(4);
        EditorGUI.DrawRect(new Rect(panel.x - 14, panel.y, EditorGUIUtility.currentViewWidth, 92), BgDark);

        GUILayout.Label("⟨ BLENDER → UNITY ⟩", _title);

        // linha de "scan" decorativa
        var line = GUILayoutUtility.GetRect(10, 2, GUILayout.ExpandWidth(true));
        EditorGUI.DrawRect(line, LineDim);
        float t = (float)(EditorApplication.timeSinceStartup % 2.0) / 2f;
        EditorGUI.DrawRect(new Rect(line.x + line.width * t, line.y, 40, 2),
                           blenderOn ? Green : Cyan);

        GUILayout.Space(6);

        // LED + estado
        using (new GUILayout.HorizontalScope())
        {
            GUILayout.Space(6);
            var led = GUILayoutUtility.GetRect(14, 14, GUILayout.Width(14));
            // brilho pulsante quando ligado
            float pulse = blenderOn ? 0.65f + 0.35f * Mathf.Sin((float)EditorApplication.timeSinceStartup * 4f) : 1f;
            EditorGUI.DrawRect(new Rect(led.x - 2, led.y + 1, 18, 18), stateColor * 0.25f);
            EditorGUI.DrawRect(new Rect(led.x + 1, led.y + 4, 12, 12), stateColor * pulse);
            GUILayout.Space(6);
            var st = new GUIStyle(_value) { normal = { textColor = stateColor } };
            GUILayout.Label(stateText, st);
            GUILayout.FlexibleSpace();
            GUILayout.Label($"OBJ {srv.ObjectCount:000}", _value);
            GUILayout.Space(6);
        }
        using (new GUILayout.HorizontalScope())
        {
            GUILayout.Space(24);
            GUILayout.Label(srv.Status, _label);
        }
        GUILayout.Space(8);
        EditorGUILayout.EndVertical();

        GUILayout.Space(6);

        // botões
        using (new GUILayout.HorizontalScope())
        {
            GUI.backgroundColor = serverOn ? Color.white : Green;
            using (new EditorGUI.DisabledScope(serverOn))
                if (GUILayout.Button("▶  INICIAR", _btn, GUILayout.Height(26))) srv.StartServer();
            GUI.backgroundColor = serverOn ? Red : Color.white;
            using (new EditorGUI.DisabledScope(!serverOn))
                if (GUILayout.Button("■  PARAR", _btn, GUILayout.Height(26))) srv.StopServer();
            GUI.backgroundColor = Color.white;
        }

        GUILayout.Space(6);
        DrawDefaultInspector();

        EditorGUILayout.HelpBox(
            "No Blender: instala blender_to_unity.py, abre a sidebar (N) → 'BlenderToUnity' → LIGAR À UNITY.",
            MessageType.Info);
    }
}
#endif
