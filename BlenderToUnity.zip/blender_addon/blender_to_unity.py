# BlenderToUnity — addon Blender
# Sincroniza malhas, transforms, hierarquia, materiais e animação (baked)
# para a Unity em tempo real via TCP.
#
# Instalação: Edit > Preferences > Add-ons > Install... > escolher este ficheiro
# Painel: Vista 3D > Sidebar (tecla N) > separador "BlenderToUnity"

bl_info = {
    "name": "BlenderToUnity",
    "author": "KialaGameStudio",
    "version": (0, 0, 3),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > BlenderToUnity",
    "description": "Sincronização em tempo real de malhas/animação para a Unity (TCP)",
    "category": "Import-Export",
}

import bpy
import hashlib
import json
import os
import socket
import struct
import tempfile
import time
import traceback
import numpy as np
from bpy.app.handlers import persistent

# ---------------------------------------------------------------------------
# Protocolo (tem de bater certo com BlenderToUnityServer.cs)
# Frame: <uint32 magic><uint32 tipo><uint32 lenJson><uint32 lenBin><json><bin>
# Tudo little-endian.
# ---------------------------------------------------------------------------
MAGIC = 0x42545531  # "BTU1"
MSG_HELLO = 1
MSG_OBJECT = 2
MSG_DELETE = 3
MSG_CLEAR = 4
MSG_TEXTURE = 5

SYNCABLE_MESH_TYPES = {"MESH", "CURVE", "SURFACE", "FONT", "META"}
SYNCABLE_TYPES = SYNCABLE_MESH_TYPES | {"EMPTY", "ARMATURE"}


class _State:
    sock = None
    connected = False
    status = "Desligado"
    dirty = set()          # nomes de objetos a (re)enviar
    synced = set()         # nomes já enviados (para detetar apagados)
    sent_textures = {}     # nome da imagem -> hash enviado (cache)
    last_reconnect = 0.0
    frame_counter = 0


S = _State()


# ---------------------------------------------------------------------------
# Rede
# ---------------------------------------------------------------------------
def _props():
    return bpy.context.scene.btu_props


def connect(host, port):
    disconnect()
    try:
        s = socket.create_connection((host, port), timeout=2.0)
        s.settimeout(5.0)
        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        S.sock = s
        S.connected = True
        S.sent_textures.clear()
        S.status = f"Ligado a {host}:{port}"
        send_frame(MSG_HELLO, {"app": "blender", "version": bpy.app.version_string})
        return True
    except Exception as e:
        S.sock = None
        S.connected = False
        S.status = f"Falha: {e}"
        return False


def disconnect():
    if S.sock:
        try:
            S.sock.close()
        except Exception:
            pass
    S.sock = None
    S.connected = False
    S.status = "Desligado"


def send_frame(msg_type, json_obj=None, bin_data=b""):
    if not S.connected or S.sock is None:
        return False
    payload = json.dumps(json_obj).encode("utf-8") if json_obj is not None else b""
    header = struct.pack("<IIII", MAGIC, msg_type, len(payload), len(bin_data))
    try:
        S.sock.sendall(header + payload + bin_data)
        return True
    except Exception as e:
        S.status = f"Ligação perdida: {e}"
        disconnect()
        S.connected = False
        return False


# ---------------------------------------------------------------------------
# Extração de dados
# ---------------------------------------------------------------------------
def _material_color(mat):
    """Cor base do material (Principled BSDF se existir)."""
    try:
        if mat and mat.use_nodes:
            for n in mat.node_tree.nodes:
                if n.type == "BSDF_PRINCIPLED":
                    return list(n.inputs["Base Color"].default_value)[:4]
        if mat:
            return list(mat.diffuse_color)[:4]
    except Exception:
        pass
    return [0.8, 0.8, 0.8, 1.0]


def _find_image_node(socket_in, _depth=0):
    """Segue as ligações de um input à procura de um nó Image Texture."""
    if _depth > 6 or socket_in is None or not socket_in.is_linked:
        return None
    for link in socket_in.links:
        node = link.from_node
        if node.type == "TEX_IMAGE" and node.image is not None:
            return node.image
        # atravessa nós intermédios (Mix, Hue/Sat, Normal Map, etc.)
        for inp in node.inputs:
            img = _find_image_node(inp, _depth + 1)
            if img is not None:
                return img
    return None


def _material_texture(mat):
    """Imagem ligada (mesmo que indiretamente) ao Base Color. Devolve bpy Image ou None."""
    try:
        if mat and mat.use_nodes:
            for n in mat.node_tree.nodes:
                if n.type == "BSDF_PRINCIPLED":
                    return _find_image_node(n.inputs["Base Color"])
    except Exception:
        pass
    return None


# (socket do Principled, chave no JSON, usage para a Unity)
_PBR_TEX_SOCKETS = (
    ("Base Color", "texture", "color"),
    ("Normal", "normalTex", "normal"),
    ("Roughness", "roughnessTex", "data"),
    ("Metallic", "metallicTex", "data"),
    ("Emission Color", "emissionTex", "color"),  # Blender 4.x
    ("Emission", "emissionTex", "color"),        # Blender 3.x
)


def _material_pbr(mat):
    """Extrai o material PBR completo do Principled BSDF.

    Devolve (info_dict, [(image, usage), ...]).
    info_dict tem cores/valores escalares + nomes das texturas de cada mapa.
    """
    info = {
        "color": [0.8, 0.8, 0.8, 1.0],
        "metallic": 0.0,
        "roughness": 0.5,
        "emission": [0.0, 0.0, 0.0],
        "texture": "",
        "normalTex": "",
        "roughnessTex": "",
        "metallicTex": "",
        "emissionTex": "",
    }
    images = []
    if mat is None:
        return info, images
    if not mat.use_nodes:
        try:
            info["color"] = list(mat.diffuse_color)[:4]
        except Exception:
            pass
        return info, images

    bsdf = next((n for n in mat.node_tree.nodes if n.type == "BSDF_PRINCIPLED"), None)
    if bsdf is None:
        return info, images

    # valores escalares (usados quando não há textura nesse canal)
    try:
        info["color"] = list(bsdf.inputs["Base Color"].default_value)[:4]
    except Exception:
        pass
    for sock, key in (("Metallic", "metallic"), ("Roughness", "roughness")):
        try:
            info[key] = float(bsdf.inputs[sock].default_value)
        except Exception:
            pass
    for sock in ("Emission Color", "Emission"):
        try:
            if sock in bsdf.inputs:
                info["emission"] = list(bsdf.inputs[sock].default_value)[:3]
                break
        except Exception:
            pass

    # texturas de cada canal (segue nós intermédios: Normal Map, Mix, etc.)
    for sock, key, usage in _PBR_TEX_SOCKETS:
        if info[key]:
            continue  # já encontrado (ex.: Emission 4.x vs 3.x)
        if sock not in bsdf.inputs:
            continue
        img = _find_image_node(bsdf.inputs[sock])
        if img is not None:
            info[key] = img.name
            images.append((img, usage))

    return info, images


def _image_bytes(img):
    """Bytes da imagem num formato que a Unity descodifica (PNG/JPG).

    1) ficheiro no disco já em PNG/JPG → lê direto;
    2) packed file em PNG/JPG → usa os bytes embebidos;
    3) resto (EXR, TGA, geradas, pintadas...) → exporta cópia em PNG.
    """
    try:
        # 1) ficheiro no disco
        if img.source == "FILE" and not img.packed_file:
            path = bpy.path.abspath(img.filepath_raw or img.filepath)
            if path and os.path.isfile(path) and path.lower().endswith((".png", ".jpg", ".jpeg")):
                with open(path, "rb") as f:
                    return f.read()

        # 2) packed file (verifica assinatura PNG/JPEG)
        if img.packed_file:
            data = bytes(img.packed_file.data)
            if data[:8] == b"\x89PNG\r\n\x1a\n" or data[:2] == b"\xff\xd8":
                return data

        # 3) reconverter para PNG via save_render
        tmp = os.path.join(tempfile.gettempdir(), "btu_tex.png")
        scene = bpy.context.scene
        prev_fmt = scene.render.image_settings.file_format
        scene.render.image_settings.file_format = "PNG"
        try:
            img.save_render(tmp, scene=scene)
        finally:
            scene.render.image_settings.file_format = prev_fmt
        with open(tmp, "rb") as f:
            return f.read()
    except Exception:
        traceback.print_exc()
    return None


def send_texture_if_needed(img, usage="color"):
    """Envia a imagem para a Unity se ainda não foi enviada (ou se mudou).

    usage: 'color' (sRGB), 'normal' (mapa de normais) ou 'data' (linear)."""
    if img is None or not S.connected:
        return
    data = _image_bytes(img)
    if not data:
        return
    digest = hashlib.md5(data).hexdigest()
    if S.sent_textures.get(img.name) == digest:
        return  # já está do lado da Unity
    fmt = "jpg" if data[:2] == b"\xff\xd8" else "png"
    if send_frame(MSG_TEXTURE, {"name": img.name, "format": fmt, "usage": usage}, data):
        S.sent_textures[img.name] = digest


def _extract_mesh(ob_eval):
    """Extrai a malha avaliada (modifiers/armature aplicados) por loop-corner.

    Devolve (meta_dict, bin_bytes) ou (None, b"") se não houver geometria.
    """
    me = ob_eval.to_mesh()
    try:
        L = len(me.loops)
        if L == 0:
            return {"vertexCount": 0, "hasUV": False, "submeshes": []}, b""

        me.calc_loop_triangles()

        # Posições por loop (vértices "split" — como a Unity precisa)
        co = np.empty(len(me.vertices) * 3, dtype=np.float32)
        me.vertices.foreach_get("co", co)
        co = co.reshape(-1, 3)
        li = np.empty(L, dtype=np.int32)
        me.loops.foreach_get("vertex_index", li)
        verts = np.ascontiguousarray(co[li], dtype=np.float32)

        # Normais por loop (Blender 4.1+ usa corner_normals)
        nor = np.empty(L * 3, dtype=np.float32)
        if hasattr(me, "corner_normals") and len(me.corner_normals) == L:
            me.corner_normals.foreach_get("vector", nor)
        else:
            try:
                me.calc_normals_split()
            except Exception:
                pass
            me.loops.foreach_get("normal", nor)

        # UVs
        has_uv = me.uv_layers.active is not None
        uv = b""
        if has_uv:
            uv_arr = np.empty(L * 2, dtype=np.float32)
            me.uv_layers.active.data.foreach_get("uv", uv_arr)
            uv = uv_arr.tobytes()

        # Triângulos + submeshes por material
        T = len(me.loop_triangles)
        tl = np.empty(T * 3, dtype=np.int32)
        me.loop_triangles.foreach_get("loops", tl)
        tl = tl.reshape(-1, 3)
        tm = np.empty(T, dtype=np.int32)
        me.loop_triangles.foreach_get("material_index", tm)

        mats = [slot.material for slot in ob_eval.material_slots]
        submeshes = []
        parts = []
        if not mats:
            info, _ = _material_pbr(None)
            info.update({"material": "Default", "indexCount": int(tl.size)})
            submeshes.append(info)
            parts.append(tl.ravel())
        else:
            tm = np.clip(tm, 0, len(mats) - 1)
            for mi in range(len(mats)):
                sel = tl[tm == mi]
                if sel.size == 0:
                    continue
                m = mats[mi]
                info, _ = _material_pbr(m)
                info.update({
                    "material": m.name if m else "Default",
                    "indexCount": int(sel.size),
                })
                submeshes.append(info)
                parts.append(sel.ravel())

        indices = (np.concatenate(parts) if parts else np.empty(0, np.int32)).astype(np.int32)

        meta = {"vertexCount": int(L), "hasUV": bool(has_uv), "submeshes": submeshes}
        bin_data = verts.tobytes() + nor.tobytes() + uv + indices.tobytes()
        return meta, bin_data
    finally:
        ob_eval.to_mesh_clear()


def build_object_message(ob, depsgraph):
    """Constrói (json, bin) para um objeto. Coordenadas em espaço Blender —
    a conversão de eixos é feita do lado da Unity."""
    loc, rot, sca = ob.matrix_local.decompose()
    try:
        visible = ob.visible_get()
    except Exception:
        visible = True

    meta = {
        "path": ob.name,
        "parent": ob.parent.name if ob.parent else "",
        "t": [loc.x, loc.y, loc.z],
        "r": [rot.x, rot.y, rot.z, rot.w],
        "s": [sca.x, sca.y, sca.z],
        "visible": bool(visible),
        "hasMesh": False,
        "vertexCount": 0,
        "hasUV": False,
        "submeshes": [],
    }
    bin_data = b""

    if ob.type in SYNCABLE_MESH_TYPES:
        ob_eval = ob.evaluated_get(depsgraph)
        try:
            mesh_meta, bin_data = _extract_mesh(ob_eval)
            if mesh_meta is not None:
                meta["hasMesh"] = True
                meta.update(mesh_meta)
        except Exception:
            traceback.print_exc()

    return meta, bin_data


# ---------------------------------------------------------------------------
# Deteção de objetos animados (para sync por frame)
# ---------------------------------------------------------------------------
def _passes_selection_filter(ob, props):
    """True se o objeto deve ser sincronizado segundo o filtro de seleção.

    Com 'Só objetos selecionados' ativo, inclui também os ancestrais dos
    selecionados (para a hierarquia ficar correta na Unity)."""
    if props.sync_scope != "SELECTED":
        return True
    try:
        if ob.select_get():
            return True
        # é ancestral de algum selecionado?
        for sel in bpy.context.selected_objects:
            p = sel.parent
            while p is not None:
                if p == ob:
                    return True
                p = p.parent
    except Exception:
        pass
    return False


def _is_animated(ob, _depth=0):
    if _depth > 8 or ob is None:
        return False
    if ob.animation_data and ob.animation_data.action:
        return True
    if getattr(ob, "constraints", None) and len(ob.constraints) > 0:
        return True
    if getattr(ob, "modifiers", None) and len(ob.modifiers) > 0:
        return True
    data = getattr(ob, "data", None)
    if data is not None and getattr(data, "animation_data", None) and data.animation_data.action:
        return True
    return _is_animated(ob.parent, _depth + 1)


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------
@persistent
def on_depsgraph_update(scene, depsgraph):
    try:
        if not S.connected or not scene.btu_props.auto_sync:
            return
        for u in depsgraph.updates:
            idd = u.id
            if isinstance(idd, bpy.types.Object):
                if idd.type in SYNCABLE_TYPES:
                    S.dirty.add(idd.name)
            elif isinstance(idd, bpy.types.Image):
                # textura editada (ex.: texture paint) → reenviar
                S.sent_textures.pop(idd.name, None)
                for ob in scene.objects:
                    if ob.type not in SYNCABLE_MESH_TYPES:
                        continue
                    for slot in ob.material_slots:
                        _, images = _material_pbr(slot.material)
                        if any(img.name == idd.name for img, _u in images):
                            S.dirty.add(ob.name)
                            break
            elif isinstance(idd, (bpy.types.Mesh, bpy.types.Curve, bpy.types.Material)):
                # marca todos os objetos que usam este data-block
                for ob in scene.objects:
                    if ob.type not in SYNCABLE_TYPES:
                        continue
                    if getattr(ob, "data", None) and ob.data.name == idd.name:
                        S.dirty.add(ob.name)
                    elif isinstance(idd, bpy.types.Material):
                        for slot in ob.material_slots:
                            if slot.material and slot.material.name == idd.name:
                                S.dirty.add(ob.name)
                                break
    except Exception:
        traceback.print_exc()


@persistent
def on_frame_change(scene, depsgraph=None):
    try:
        if not S.connected or not scene.btu_props.auto_sync or not scene.btu_props.sync_animation:
            return
        S.frame_counter += 1
        if S.frame_counter % max(1, scene.btu_props.frame_skip) != 0:
            return
        for ob in scene.objects:
            if ob.type in SYNCABLE_TYPES and _is_animated(ob):
                S.dirty.add(ob.name)
    except Exception:
        traceback.print_exc()


@persistent
def on_load(_dummy):
    S.dirty.clear()
    S.synced.clear()
    disconnect()


# ---------------------------------------------------------------------------
# Timer de envio (corre na thread principal do Blender)
# ---------------------------------------------------------------------------
def flush_timer():
    try:
        props = bpy.context.scene.btu_props
    except Exception:
        return 0.5

    interval = max(0.02, props.interval)

    # auto-reconectar
    if not S.connected and props.auto_sync and props.auto_reconnect:
        now = time.time()
        if now - S.last_reconnect > 3.0:
            S.last_reconnect = now
            connect(props.host, props.port)

    if not S.connected:
        return interval

    try:
        scene = bpy.context.scene
        current = {ob.name for ob in scene.objects if ob.type in SYNCABLE_TYPES}

        # objetos apagados
        for name in list(S.synced - current):
            send_frame(MSG_DELETE, {"path": name})
            S.synced.discard(name)

        if S.dirty:
            depsgraph = bpy.context.evaluated_depsgraph_get()
            for name in list(S.dirty):
                S.dirty.discard(name)
                ob = scene.objects.get(name)
                if ob is None or ob.type not in SYNCABLE_TYPES:
                    continue
                if not _passes_selection_filter(ob, props):
                    continue
                # texturas primeiro, para a Unity já as ter quando o objeto chegar
                if props.send_textures and ob.type in SYNCABLE_MESH_TYPES:
                    for slot in ob.material_slots:
                        _, images = _material_pbr(slot.material)
                        for img, usage in images:
                            send_texture_if_needed(img, usage)
                meta, bin_data = build_object_message(ob, depsgraph)
                if send_frame(MSG_OBJECT, meta, bin_data):
                    S.synced.add(name)
                else:
                    break  # ligação caiu
    except Exception:
        traceback.print_exc()

    return interval


# ---------------------------------------------------------------------------
# Propriedades + UI
# ---------------------------------------------------------------------------
class BTU_Props(bpy.types.PropertyGroup):
    host: bpy.props.StringProperty(name="Host", default="127.0.0.1")
    port: bpy.props.IntProperty(name="Porta", default=9931, min=1, max=65535)
    auto_sync: bpy.props.BoolProperty(
        name="Sync automático", default=True,
        description="Envia alterações automaticamente enquanto editas")
    sync_scope: bpy.props.EnumProperty(
        name="Enviar",
        description="Que objetos são sincronizados para a Unity",
        items=[
            ("ALL", "Todos os Objetos", "Sincroniza a cena inteira", "SCENE_DATA", 0),
            ("SELECTED", "Só Selecionados", "Sincroniza apenas os objetos selecionados (e os pais, para manter a hierarquia)", "RESTRICT_SELECT_OFF", 1),
        ],
        default="ALL")
    send_textures: bpy.props.BoolProperty(
        name="Enviar texturas", default=True,
        description="Envia as imagens dos materiais para a Unity (desliga para acelerar em cenas pesadas)")
    sync_animation: bpy.props.BoolProperty(
        name="Sync de animação", default=True,
        description="Envia malhas deformadas a cada mudança de frame (armatures, shape keys, etc.)")
    interval: bpy.props.FloatProperty(
        name="Intervalo (s)", default=0.1, min=0.02, max=2.0,
        description="Frequência de envio das alterações")
    frame_skip: bpy.props.IntProperty(
        name="Enviar a cada N frames", default=1, min=1, max=10,
        description="Durante a animação, envia 1 em cada N frames (poupa largura de banda)")
    auto_reconnect: bpy.props.BoolProperty(name="Reconectar automaticamente", default=True)


class BTU_OT_connect(bpy.types.Operator):
    bl_idname = "btu.connect"
    bl_label = "Ligar"
    bl_description = "Liga ao servidor BlenderToUnity na Unity"

    def execute(self, context):
        p = context.scene.btu_props
        if connect(p.host, p.port):
            self.report({"INFO"}, S.status)
            bpy.ops.btu.sync_all()
        else:
            self.report({"ERROR"}, S.status)
        return {"FINISHED"}


class BTU_OT_disconnect(bpy.types.Operator):
    bl_idname = "btu.disconnect"
    bl_label = "Desligar"

    def execute(self, context):
        disconnect()
        return {"FINISHED"}


class BTU_OT_sync_all(bpy.types.Operator):
    bl_idname = "btu.sync_all"
    bl_label = "Sincronizar tudo"
    bl_description = "Reenvia todos os objetos da cena"

    def execute(self, context):
        if not S.connected:
            self.report({"ERROR"}, "Não está ligado")
            return {"CANCELLED"}
        for ob in context.scene.objects:
            if ob.type in SYNCABLE_TYPES:
                S.dirty.add(ob.name)
        return {"FINISHED"}


class BTU_OT_clear_remote(bpy.types.Operator):
    bl_idname = "btu.clear_remote"
    bl_label = "Limpar na Unity"
    bl_description = "Apaga todos os objetos sincronizados do lado da Unity"

    def execute(self, context):
        if not S.connected:
            self.report({"ERROR"}, "Não está ligado")
            return {"CANCELLED"}
        send_frame(MSG_CLEAR)
        S.synced.clear()
        return {"FINISHED"}


def _icon(name, fallback="NONE"):
    """Devolve o ícone se existir nesta versão do Blender, senão o fallback.
    (Ícones mudam de nome entre versões — ex.: SEQUENCE_COLOR_* no Blender 5.x)"""
    try:
        if name in bpy.types.UILayout.bl_rna.functions["label"].parameters["icon"].enum_items:
            return name
    except Exception:
        pass
    return fallback


class BTU_PT_panel(bpy.types.Panel):
    bl_label = "BlenderToUnity v0.0.3"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "BlenderToUnity"

    def draw(self, context):
        layout = self.layout
        try:
            self._draw_body(layout, context)
        except Exception:
            # nunca deixar o painel "vazio": mostrar o erro
            import traceback as _tb
            _tb.print_exc()
            layout.label(text="Erro ao desenhar o painel:", icon="ERROR")
            for ln in _tb.format_exc().splitlines()[-2:]:
                layout.label(text=ln[:60])

    def _draw_body(self, layout, context):
        p = getattr(context.scene, "btu_props", None)
        if p is None:
            layout.label(text="Erro: propriedades não registadas.", icon="ERROR")
            layout.label(text="Remove versões antigas do addon e reinicia o Blender.")
            return

        # ── estado da ligação ─────────────────────────────
        box = layout.box()
        row = box.row()
        if S.connected:
            row.alert = False
            row.label(text="ONLINE — " + S.status,
                      icon=_icon("SEQUENCE_COLOR_04", _icon("CHECKMARK", "LINKED")))
        else:
            row.alert = True
            row.label(text="OFFLINE — " + S.status,
                      icon=_icon("SEQUENCE_COLOR_01", _icon("X", "UNLINKED")))

        row = box.row(align=True)
        row.prop(p, "host", text="")
        row.prop(p, "port", text="")
        row = box.row()
        row.scale_y = 1.4
        if S.connected:
            row.operator("btu.disconnect", text="DESLIGAR", icon=_icon("UNLINKED"))
        else:
            row.operator("btu.connect", text="LIGAR À UNITY", icon=_icon("LINKED"))

        # ── âmbito do envio ───────────────────────────────
        box = layout.box()
        box.label(text="Âmbito", icon=_icon("OUTLINER_OB_GROUP_INSTANCE"))
        box.row().prop(p, "sync_scope", expand=True)
        if p.sync_scope == "SELECTED":
            n = len(context.selected_objects)
            box.label(text=f"{n} objeto(s) selecionado(s)",
                      icon=_icon("RESTRICT_SELECT_OFF"))

        # ── opções de sincronização ───────────────────────
        box = layout.box()
        box.label(text="Sincronização", icon=_icon("UV_SYNC_SELECT"))
        col = box.column(align=True)
        col.prop(p, "auto_sync", icon=_icon("AUTO"))
        col.prop(p, "send_textures", icon=_icon("TEXTURE"))
        col.prop(p, "sync_animation", icon=_icon("ARMATURE_DATA"))
        col.prop(p, "auto_reconnect", icon=_icon("FILE_REFRESH"))
        col = box.column(align=True)
        col.prop(p, "interval")
        col.prop(p, "frame_skip")

        # ── ações ─────────────────────────────────────────
        box = layout.box()
        box.label(text="Ações", icon=_icon("PLAY"))
        row = box.row(align=True)
        row.scale_y = 1.2
        row.operator("btu.sync_all", text="Sincronizar", icon=_icon("FILE_REFRESH"))
        row.operator("btu.clear_remote", text="Limpar", icon=_icon("TRASH"))


# ---------------------------------------------------------------------------
# Registo
# ---------------------------------------------------------------------------
classes = (BTU_Props, BTU_OT_connect, BTU_OT_disconnect,
           BTU_OT_sync_all, BTU_OT_clear_remote, BTU_PT_panel)


def register():
    # limpa restos de versões antigas (evita conflito de registo)
    for c in classes:
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.btu_props = bpy.props.PointerProperty(type=BTU_Props)
    bpy.app.handlers.depsgraph_update_post.append(on_depsgraph_update)
    bpy.app.handlers.frame_change_post.append(on_frame_change)
    bpy.app.handlers.load_post.append(on_load)
    if not bpy.app.timers.is_registered(flush_timer):
        bpy.app.timers.register(flush_timer, first_interval=0.5, persistent=True)


def unregister():
    disconnect()
    if bpy.app.timers.is_registered(flush_timer):
        bpy.app.timers.unregister(flush_timer)
    for h, fn in ((bpy.app.handlers.depsgraph_update_post, on_depsgraph_update),
                  (bpy.app.handlers.frame_change_post, on_frame_change),
                  (bpy.app.handlers.load_post, on_load)):
        if fn in h:
            h.remove(fn)
    del bpy.types.Scene.btu_props
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
